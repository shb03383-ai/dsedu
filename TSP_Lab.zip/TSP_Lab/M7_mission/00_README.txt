[M7 조별 통합 미션]

여러 파일을 연결해 원인 → 영향 범위 → 고객 회신 → 보고까지 조별로 프롬프트를 설계한다.

이 폴더의 파일 설명 (파일명은 영어, 내용은 한국어)
--------------------------------------------------
MISSION.txt                              미션 설명서 (빔에 띄우기)
source/                                  미션 원본자료 — 앞 모듈 파일 사본 (아래 ↓). 수정 금지
  tester_results/                        테스터 6대 9월 결과 CSV (M2와 같음)
  product_info.xlsx                      목표수율·BIN 코드 (M2와 같음)
  strip_map_TL260916B.csv                문제 LOT 스트립맵 (M2와 같음)
  alarm_log_202609.txt                   9월 알람 로그 (M3와 같음)
  consumable_life.xlsx                   소모품 수명 (M3와 같음)
  material_lot_trace.xlsx                LOT별 자재·설비 이력 (M4와 같음)
  defect_memo_TL260916B.txt              불량 분석 메모 (M4와 같음)
  customer_mail_DeltaMicro.txt           고객 클레임 메일 (M4와 같음)
  8D_template.docx                       8D 양식 (M4와 같음)
  defect_photos/                         불량 사진 3장 (M5에서 일부)
  whiteboard_meeting.jpg                 긴급회의 화이트보드 (M5와 같음)
  weekly_report_template.pptx            주간보고 PPT 양식 (M6와 같음)
output/                                  결과물 저장 폴더 (비어 있음)

※ 모든 데이터는 교육용 가상 데이터입니다 (실제 제품·고객·수치와 무관).
