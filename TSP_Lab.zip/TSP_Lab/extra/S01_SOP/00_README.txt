[S01 SOP 문서 서식·개정 비교]

이 폴더의 파일 설명 (파일명은 영어, 내용은 한국어)
--------------------------------------------------
SOP_wire_bonding_Rev3.docx               와이어본딩 작업표준서 Rev.3
SOP_wire_bonding_Rev4.docx               와이어본딩 작업표준서 Rev.4 (개정본)
work_standard_molding.docx               몰딩 작업 지침 (서식 다름: 굴림, - 기호)
test_process_SOP(v2).docx                테스트 공정 SOP (서식 다름: Arial, 1) 번호)

※ 모든 데이터는 교육용 가상 데이터입니다 (실제 제품·고객·수치와 무관).
