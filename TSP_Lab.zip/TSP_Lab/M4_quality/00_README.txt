[M4 품질 · 오류 검수]

AI 검수는 '시킨 만큼' 한다는 걸 체감한다(사람 vs AI). 원본 시트를 복사해 고치는 법, 8D 초안 작성.

이 폴더의 파일 설명 (파일명은 영어, 내용은 한국어)
--------------------------------------------------
error_check_Sep_test_data.xlsx           9월 테스트 데이터 ★오류 19개를 일부러 숨겨둔 파일
SPC_wire_pull.csv                        와이어본더 4대의 와이어 풀 강도 측정값 (하루 5샘플)
SPC_criteria.txt                         풀 강도 규격(하한 6.0 / 상한 11.0 gf)과 Cpk 기준 1.33
package_thickness.csv                    패키지 두께 측정값 ★mm와 μm 단위가 섞여 있음
defect_memo_TL260916B.txt                품질팀의 정리 안 된 불량 분석 메모
customer_mail_DeltaMicro.txt             고객사 Delta Micro의 영문 클레임 메일
8D_template.docx                         빈 8D 보고서 양식 (워드)
material_lot_trace.xlsx                  LOT별 사용 자재·설비·캐필러리 이력 (역추적용)
change_4M_202609.xlsx                    9월 4M 변경점 이력 (사람·설비·자재·방법)
FMEA_package.xlsx                        패키지 공정 FMEA (RPN = S×O×D 수식)

※ 모든 데이터는 교육용 가상 데이터입니다 (실제 제품·고객·수치와 무관).
