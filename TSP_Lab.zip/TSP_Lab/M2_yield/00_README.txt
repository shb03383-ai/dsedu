[M2 테스트 데이터 · 수율]

CSV 여러 개 합치기 → 계산 열 추가 → 집계·차트 → 시트 복사까지 한 번에 시킨다.

이 폴더의 파일 설명 (파일명은 영어, 내용은 한국어)
--------------------------------------------------
tester_results/                          테스터 6대의 9월 결과 CSV 6개 (TST-01_202609.csv ~ TST-06_202609.csv). LOT마다 투입수량, BIN1~BIN8 수량
product_info.xlsx                        제품 3종의 고객사·목표수율 + BIN 코드 뜻 (BIN1=양품, BIN2=Open …)
strip_map_TL260916B.csv                  문제 LOT의 스트립 위치(행·열)별 Pass/Fail
strip_map_TL260910B.csv                  비교용 정상 LOT의 스트립맵
retest_history_202609.csv                목표 미달 LOT의 재테스트 이력

※ 모든 데이터는 교육용 가상 데이터입니다 (실제 제품·고객·수치와 무관).
