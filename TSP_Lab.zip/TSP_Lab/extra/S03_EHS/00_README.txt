[S03 EHS · 안전]

이 폴더의 파일 설명 (파일명은 영어, 내용은 한국어)
--------------------------------------------------
safety_check_lineA_0924.xlsx             A라인 안전점검표
safety_check_lineB_0924.xlsx             B라인 안전점검표
safety_check_lineC_0924.xlsx             C라인 안전점검표
MSDS_FX-200.pdf                          솔더 플럭스 MSDS (가상)
MSDS_CL-50.pdf                           세정제 MSDS (가상)
MSDS_EP-12.pdf                           에폭시 MSDS (가상)
near_miss_Q3.xlsx                        3분기 아차사고 보고 36건

※ 모든 데이터는 교육용 가상 데이터입니다 (실제 제품·고객·수치와 무관).
