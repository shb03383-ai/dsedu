[S04 보안 · 개인정보 검수]

이 폴더의 파일 설명 (파일명은 영어, 내용은 한국어)
--------------------------------------------------
worker_contacts.xlsx                     작업자 비상연락망 (전화번호)
insurance_list.xlsx                      보험 가입 대상자 (주민번호)
vendor_contacts_memo.txt                 협력사 담당자 메모 (전화·이메일)
travel_expense_Sep.csv                   출장 정산 (계좌번호)
team_dinner_list.docx                    회식 참석 명단 (사번·전화)
Sep_process_meeting.txt                  공정 회의록 (개인정보 없음)
00_README.txt                            모든 개인정보는 가짜 값이라는 안내

※ 모든 데이터는 교육용 가상 데이터입니다 (실제 제품·고객·수치와 무관).
