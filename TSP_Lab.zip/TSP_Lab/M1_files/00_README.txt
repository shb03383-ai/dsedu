[M1 파일 관리 · 확장자 · 형식 변환]

백업 → 미리보기 → 실행 순서를 몸에 익힌다. '확장자만 바꾸기'와 '진짜 형식 변환'의 차이를 안다.

이 폴더의 파일 설명 (파일명은 영어, 내용은 한국어)
--------------------------------------------------
messy_folder/                            이름·형식이 엉망인 파일 18개 (아래 ↓ 항목들). 정리 실습용
  yield data Sep 1.csv                   9/1 LOT별 수율 데이터
  TST04_0915_lot TL260915B.csv           TST-04 테스터, 9/15, LOT 1개 결과
  measure data 9-21.csv                  9/21 와이어 풀강도 측정값
  shipping_20260920.csv                  9/17~20 출하 현황
  test_result(final).xlsx                9월 1주차 테스트 결과
  test_result(final)(1).xlsx             위 파일과 내용이 완전히 같은 중복본
  test_result_final_REAL_final.xlsx      ★함정: 거의 같지만 1개 행 숫자가 다름 (중복 아님)
  PM plan (edited).xlsx                  10월 설비 PM 계획
  ~$test_result(final).xlsx              엑셀 임시 잠금파일 (지워도 되는 쓰레기)
  2026.09.16_WB03_alarm.txt              9/16 WB-03 알람 메모
  New Text Document.txt                  0바이트 빈 파일
  16-09-2026 defect photo.jpg            불량 사진 (날짜가 일-월-년 순서라 헷갈림)
  IMG_20260918_143022.jpg                9/18 캐필러리 교체 작업 사진
  Capture.PNG                            TST-04 BIN2 알림 화면 캡처
  meeting_0918.docx                      9/18 품질 회의록 (워드)
  weekly report Sep W3.pptx              9월 3주차 주간보고 (PPT)
  SCAN0001.pdf                           출하검사 성적서 사본
  tpx-b200 spec revB.pdf                 고객 스펙 요약본
extension_practice/                      확장자가 제각각인 파일 12개: 로그(.TXT .Txt .log .txt), 사진(.JPEG .JPG .jpeg .jpg .png), CSV(.CSV .csv)
equipment_list_broken_in_excel.csv       설비 목록 — 엑셀로 열면 한글이 깨짐 (UTF-8, BOM 없음)
equipment_list_cp949.csv                 설비 목록 — CP949 인코딩 (일부 프로그램에서 깨짐)
equipment_uptime_0910.xlsx               설비 가동 현황 ★가짜 확장자: 실제로는 CSV 텍스트
measurement_report.pdf                   측정 결과 ★가짜 확장자: 실제로는 PNG 이미지
Sep_output_by_line.xlsx                  라인별(A~D) 9월 실적 — 시트 4개
alarm_zips/                              9/14~17 알람 로그 압축파일 4개 (alarm_20260914.zip …)

※ 모든 데이터는 교육용 가상 데이터입니다 (실제 제품·고객·수치와 무관).
