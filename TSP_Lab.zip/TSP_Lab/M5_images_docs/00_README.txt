[M5 이미지 · PDF · 문서]

사진·캡처·스캔본처럼 '글자가 아닌 파일'도 데이터로 바꾼다. PDF 비교·병합·요약.

이 폴더의 파일 설명 (파일명은 영어, 내용은 한국어)
--------------------------------------------------
handwritten_daily_check.jpg              손글씨 일일 점검표 사진 (강사가 직접 쓴 사진으로 교체 권장)
whiteboard_meeting.jpg                   9/18 긴급회의 화이트보드 사진
equipment_screens/                       설비 에러 화면 캡처 4장 (WB-03, TST-04, MLD-02, SAW-02)
defect_photos/                           패키지 불량 사진 10장, 이름 제각각 (스크래치·이물·크랙·칩핑·마킹불량·정상)
customer_spec_TPX-B200_RevA.pdf          고객 스펙 — 개정 전
customer_spec_TPX-B200_RevB.pdf          고객 스펙 — 개정 후 (8개 항목 변경)
manual_WB-Series_EN.pdf                  와이어본더 영문 매뉴얼 발췌 (알람 조치, 캐필러리 수명)
inspection_reports/                      출하검사 성적서 PDF 3개 (report_TL260920A.pdf …) — 병합용
scanned_inspection_report.pdf            스캔 이미지로만 된 성적서 (글자 선택이 안 되는 PDF)
before_after/                            정리정돈 개선 전·후 사진 4장 (tool_rack_before.jpg …)

※ 모든 데이터는 교육용 가상 데이터입니다 (실제 제품·고객·수치와 무관).
