[M6 보고 자동화]

회사 PPT 양식을 그대로 쓰는 보고서 만들기, 그리고 보고서 숫자를 원본과 대조하는 '검증' 습관.

이 폴더의 파일 설명 (파일명은 영어, 내용은 한국어)
--------------------------------------------------
daily_output/                            라인 4개의 9월 일일 실적 엑셀 (daily_output_lineA_202609.xlsx ~ lineD)
production_plan_202609.xlsx              주차·제품별 생산 계획
shipment_202609.csv                      9월 출하 실적 (고객사·제품·수량)
WIP_20260930.csv                         9/30 기준 공정별 재공(WIP) 수량
weekly_report_template.pptx              회사 주간보고 PPT 양식 (남색 상단바)
Sep_quality_report_draft.docx            9월 품질보고서 초안 (워드) ★숫자 3개가 틀림

※ 모든 데이터는 교육용 가상 데이터입니다 (실제 제품·고객·수치와 무관).
